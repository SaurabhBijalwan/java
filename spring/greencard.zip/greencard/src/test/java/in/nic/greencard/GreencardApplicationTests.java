package in.nic.greencard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GreencardApplicationTests {

	@Test
	void contextLoads() {
	}

}
