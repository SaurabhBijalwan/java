package in.nic.dlservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DlServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
