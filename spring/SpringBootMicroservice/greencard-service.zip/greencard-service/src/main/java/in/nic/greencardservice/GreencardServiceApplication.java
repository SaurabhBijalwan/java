package in.nic.greencardservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GreencardServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(GreencardServiceApplication.class, args);
	}

}
