package in.nic.greencardservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GreencardServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
