import React from 'react';
import ReactDOM from 'react-dom';
import HooksComponent from './Component/HooksComponent.jsx';

ReactDOM.render(<HooksComponent/>,document.getElementById('root'));