import React from 'react';

const Footer = () => {
    return(
        <footer>
            <div>
                <hr/>
                &copy; Developer Funnel
            </div>
        </footer>
    )
}

export default Footer;