import React from 'react';

const Footer = () => {
    return(
        <div>
            <center>
                <h4>&copy; Developer Funnel</h4>
            </center>

        </div>
    )
}

export default Footer;