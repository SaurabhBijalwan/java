export function MoviesList(){
    return{
        type:'MOVIE_LIST',
        payload:[
            {id:1,name:'Mad MAx'},
            {id:2,name:'Blood Diamond'},
            {id:3,name:'Avengers'}
        ]
    }
}