export const getMovies = () => ({   
    type:'GET_MOVIES'
})


export const getLatest = () => ({   
    type:'GET_Latest_MOVIES'
})
